# 🎮 Tic-Tac-Toe Game

A simple and interactive **Tic-Tac-Toe** game built using **HTML**, **CSS**, and **JavaScript**. This game is designed for two players, with a clean UI and smooth game logic.

## 📸 Screenshots

### Game Interface:
![Game UI](./screenshots/game-ui.png)

### Winning Screen:
![Winner Screen](./screenshots/winner-ui.png)

### New Game Screen:
![New Game Screen](./screenshots/newgame-ui.png)

## 🛠️ Features

- Two-player turn-based gameplay
- Win detection with horizontal, vertical, and diagonal patterns
- Displays the winner with a congratulatory message
- Reset and New Game functionality
- Responsive and minimalistic UI

## 💻 Technologies Used

- **HTML5** – for structure
- **CSS3** – for styling and layout
- **JavaScript (Vanilla)** – for game logic

## 🚀 How to Run Locally

1. **Clone the repository:**
   ```bash
   git clone https://github.com/Ranjitha110/Tic-Tac-Toe.git
   ```

2. **Navigate into the project directory:**
   ```bash
   cd Tic-Tac-Toe
   ```

3. **Open `index.html` in your browser**  
   You can simply double-click on `index.html` or run with Live Server in VS Code.

## 🧠 Game Logic

- The board consists of 9 boxes.
- Each player takes turns to place either "X" or "O".
- The game checks for winning combinations after every move.
- If a player wins, the board hides and a winner message is displayed.
- A reset/new game button allows users to replay.

## 📂 Project Structure

```
Tic-Tac-Toe/
├── index.html        # Main HTML file
├── style.css         # Styling for game board and UI
├── first.js          # JavaScript logic for gameplay
├── screenshots/      # Game screenshots
└── README.md         # Project documentation
```

## 📬 Contact

**Ranjitha Karnadi**  
📧 [LinkedIn](https://www.linkedin.com/in/ranjitha-karnadi-984980220/)  
📦 [GitHub](https://github.com/Ranjitha110)

## 📃 License

This project is licensed under the [MIT License](LICENSE).
